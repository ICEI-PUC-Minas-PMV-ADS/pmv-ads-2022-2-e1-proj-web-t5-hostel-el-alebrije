function enviarForm() {
    alert('Avaliação enviada com sucesso!')
  }