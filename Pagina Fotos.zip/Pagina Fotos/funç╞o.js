function img01 (){
    document.getElementById("trocarimg").src="trocaimg01.jpg";
}
function img02 (){
    document.getElementById("trocarimg").src="trocaimg02.jpg";
}
function img03 (){
    document.getElementById("trocarimg").src="trocaimg03.jpg";
}
function img04 (){
    document.getElementById("trocarimg").src="trocaimg04.jpg";
}
function img05 (){
    document.getElementById("trocarimg").src="trocaimg05.jpg";
}
function img06 (){
    document.getElementById("trocarimg").src="trocaimg06.jpg";
}
function img07 (){
    document.getElementById("trocarimg").src="trocaimg07.jpg";
}
function img08 (){
    document.getElementById("trocarimg").src="trocaimg08.jpg";
}
function img09 (){
    document.getElementById("trocarimg").src="trocaimg09.jpg";
}
function img10 (){
    document.getElementById("trocarimg").src="trocaimg10.jpg";
}
function img11 (){
    document.getElementById("trocarimg").src="trocaimg11.jpg";
}
function img12 (){
    document.getElementById("trocarimg").src="trocaimg12.jpg";
}
